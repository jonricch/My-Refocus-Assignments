const birth_year = 1991;
let birth_month = 01;
const current_month = new Date().getMonth();
let current_year = new Date().getFullYear();

current_year -= 1;
age = current_year - birth_year;

if (birth_month <= current_month) {
  age++;

  console.log(`Patient’s Accurate Age: ${age}`);
} else {
  console.log(`Patient’s Accurate Age: ${age}`);
}
