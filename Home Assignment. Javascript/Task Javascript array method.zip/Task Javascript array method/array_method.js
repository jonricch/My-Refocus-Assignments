const arr = [
    "Web Developer",
    "Refocus",
    "Web Developer",
    "Web Developer",
    "Refocus",
    "Awesome"
];




function getWordCount (arr) {
    let map = {};

    for (let i = 0 ; i < arr.length; i++) {
        let item = arr[i];
        map[item] = (map [item] + 1) || 1;
    }

    return map;
}

console.log(getWordCount(arr));