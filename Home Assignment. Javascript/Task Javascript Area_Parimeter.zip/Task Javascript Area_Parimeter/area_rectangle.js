var width = 16
var length = 20

var area = (length * width)

console.log(`Width: ${width}`)
console.log(`Length: ${length}`)
console.log(`Area: ${area}`)