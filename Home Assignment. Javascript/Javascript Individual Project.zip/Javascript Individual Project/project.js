var shopName = [
    {
        shop: "Lazada",
        address: "Marajo Tower, 312 4th Ave, Taguig, 1434 Metro Manila",
        code: "MNL001"
    },
    {
        shop: "Shopee",
        address: "Seven/NEO, 5th Ave, Taguig, Metro Manila",
        code: "MNL002"
    },
    {
        shop: "Alibaba",
        address: "969 West Wen Yi Road, Yuhang District, Hangzhou, Zhejiang, China and George Town, Cayman Islands.",
        code: "CHN285"
    }

]

var uSer = [
    {
        Name: "lylia",
        lastname: "Nightshade",
        age: 28,
        birthday: "10.08.1994",
        userID: "lylianight",
        password: "lylia123"
    },
    {
        Name: "Angeli",
        lastname: "Khang",
        age: 21,
        birthday: "08.03.2001",
        userID: "angeliviva",
        password: "angeli143"
    },
    {
        Name: "Azi",
        lastname: "Acosta",
        age: 20,
        birthday: "09.08.2002",
        userID: "aziviva",
        password:"aziacosta143"
    }
]

var items = [
    {
        item: "Leather jacket",
        category: "Jacket",
        price_$: 500,
        stock: 10
    },
    {
        item: "Leggings",
        category: "Pants",
        price_$: 899,
        stock: 2
    },
    {
        item: "Blouse",
        category: "Women's tops",
        price_$: 499,
        stock: 1
    },
   
];

// Add User

function addUser(info) {
    uSer.push(info);

   console.log( info.Name + " " + info.lastname + " has been added")
}

addUser({
    Name: "Edith",
    lastname: "lightburn",
    age: 25,
    birthday: "02.14.1998"
})

// Adding items and stocks

  
  function addStocks(itemName, quantity) {
 
    const itemIndex = items.findIndex(item => item.item === itemName);
    
    
    if (itemIndex === -1) {
      console.log(`Item ${itemName} not found in inventory`);
    } else {
     
      items[itemIndex].stock += quantity;
      console.log(`Added ${quantity} stocks to ${itemName}`);
    }
  }
  
  
  addStocks(`Leather Jacket`, 5); 
  addStocks(`Blouse`, 3); 
  addStocks(`Leggings`, 2); 
  addStocks(`Hoodie`, 5)

/**
  In this example, we have an inventory array that contains items and their current stocks. We also have a 
  function addStocks that takes two arguments: the name of the item to add stocks to, and the quantity of 
 stocks to add.

Inside the function, we use the findIndex method to find the index of the item in the inventory array. 
If the item is not found, we print an error message. Otherwise, we use array indexing to access the item's
 stock property and add the specified quantity. We then print a message to confirm that the stocks have been
added.

We can call the addStocks function with different arguments to add stocks to different items in the inventory. If we pass the name of an item that does not exist in the inventory, the function prints an error message.
 */

//Log in User
  
var isLoggedIn = false;
var userID = null;

function loginUser(username, password){ 
    uSer.forEach((element, index) => {

        if (element.userID == username && element.password == password) {
            isLoggedIn = false ;
            userID = index;

            console.log("Hi " + element.Name + " " + element.lastname + " Welcome to our shop")
        }
    })

    if (isLoggedIn) {
        userID = null;

        console.log("Please Log in")
    }

}



// Add items to the cart when a user is logged in.
  

 // Define an empty cart array to store items
let cart = [];

// Define a function to add items to the cart
function addToCart(itemIndex) {
  // Check if a user is logged in
  if (userID !== null) {
    // Find the item in the items array by its index
    const item = items[itemIndex];
    
    if (item) {
      // Check if the item is in stock
      if (item.stock > 0) {
        // Add the item to the cart
        cart.push(item);
        // Decrease the item stock by 1
        item.stock--;
        console.log(`Added ${item.item} to cart`);
      } else {
        console.log(`${item.item} is out of stock`);
      }
    } else {
      console.log(`Item with index ${itemIndex} not found`);
    }
  } else {
    console.log("Please log in to add items to cart");
  }
}

/*
In this example, we first define an empty cart array to store the items that the user adds to the cart.

We then define a function addToCart that takes an item index as an argument. Inside the function, we first 
check if a user is logged in using the userID variable. If a user is logged in, we use the item index to find 
the item in the items array. If the item is found, we check if the item is in stock by looking at the stock 
property of the item. If the item is in stock, we add it to the cart using the push method, decrease the item 
stock by 1, and print a message to confirm that the item has been added to the cart. If the item is out of 
stock, we print a message to inform the user. If the item is not found in the items array, we print an error
 message.

If a user is not logged in, we print a message to prompt the user to log in before adding items to the cart.

To log in a user, we call the loginUser function and pass a username and password as arguments. The function 
loops through the uSer array to find a user with the matching userID and password. If a matching user is found,
 we set the userID variable to the index of the user in the uSer array and print a welcome message. If no 
 matching user is found, we set the userID variable to null and print a message to prompt the user to log in.

We can call the addToCart function with different item indices to add items to the cart. If we call the 
function with an out-of-stock item or an item index that does not exist in the items array, the function 
prints an error message.

*/


// Confirm an order

// Function to confirm an order
function confirmOrder(userID, cartItems) {
    // Check if user is logged in
    if (userID !== null) {
      // Loop through the cart items and update the stock of each item
      cartItems.forEach(cartItem => {
        items.forEach(item => {
          if (cartItem.item === item.item) {
            // Check if there's enough stock of the item
            if (cartItem.quantity <= item.stock) {
              // Subtract the quantity of the item from the stock
              item.stock -= cartItem.quantity;
              console.log("Confirmed order for " + cartItem.item);
            } else {
              console.log("Sorry, there's not enough stock for " + cartItem.item);
            }
          }
        });
      });
    } else {
      console.log("Please log in to confirm your order.");
    }
  }
  
 /*
 In this script, the confirmOrder() function takes two parameters: the userID of the logged-in user, and an 
 array of cartItems containing the items and their corresponding quantities in the user's cart. The function
 first checks if the user is logged in, and then loops through the cart items. For each cart item, the 
 function searches the items array for a matching item name, and checks if there's enough stock to fulfill 
 the order. If there's enough stock, the function subtracts the quantity of the item from the stock, and logs
 a message confirming the order. If there's not enough stock, the function logs a message indicating the 
 item is out of stock. If the user is not logged in, the function logs a message asking the user to log in 
 to confirm their order 



 */

   
  var cartItems = [
    { item: "Leather jacket", quantity: 1 },
    { item: "Blouse", quantity: 1 }
  ];
  
  

  function deductStocks(userID, cartItems) {
    // Check if user is logged in
    if (userID !== null) {
      // Loop through the cart items and update the stock of each item
      cartItems.forEach(cartItem => {
        items.forEach(item => {
          if (cartItem.item === item.item) {
            // Subtract the quantity of the item from the stock
            item.stock -= cartItem.quantity;
            console.log("Deducted " + cartItem.quantity + " " + cartItem.item + " from the stock.");
          }
        });
      });
    } else {
      console.log("Please log in to deduct stocks.");
    }
  }
  
 /*
 In this function, the deductStocks() function takes two parameters: the userID of the logged-in user, and an 
 array of cartItems containing the items and their corresponding quantities in the user's cart. The function 
 first checks if the user is logged in, and then loops through the cart items. For each cart item, the 
 function searches the items array for a matching item name, and subtracts the quantity of the item from the 
 stock. The function logs a message indicating the quantity of the item that was deducted from the stock. If 
 the user is not logged in, the function logs a message asking the user to log in to deduct stocks.
 
 
 */



  var cartItems = [
    { item: "Leather jacket", quantity: 1 },
    { item: "Blouse", quantity: 1 }
  ];

 
  

// Calculate the change, and show the receipt

  function showReceipt(userID, cartItems, payment) {
    var subtotal = 0;
    var tax = 0;
    var total = 0;
    var change = 0;
    
    // Check if user is logged in
    if (userID !== null) {
      console.log("Receipt for UserID: " + uSer[userID].userID);
      console.log("---------------------------");
      
      // Calculate the subtotal, tax, and total of the purchased items
      cartItems.forEach(cartItem => {
        items.forEach(item => {
          if (cartItem.item === item.item) {
            subtotal += item.price_$ * cartItem.quantity;
          }
        });
      });
      tax = subtotal * 0.12;
      total = subtotal + tax;
      
      console.log("Subtotal: ₱" + subtotal.toFixed(2));
      console.log("Tax: ₱" + tax.toFixed(2));
      console.log("Total: ₱" + total.toFixed(2));
      
      // Check if payment is enough to cover the total
      if (payment >= total) {
        change = payment - total;
        console.log("Payment: ₱" + payment.toFixed(2));
        console.log("Change: ₱" + change.toFixed(2));
      } else {
        console.log("Insufficient payment.");
      }
    } else {
      console.log("Please log in to show receipt.");
    }
  }
  

  
  var cartItems = [
    { item: "Leggings", quantity: 1 },
    { item: "Blouse", quantity: 1 }
  ];


/* 
In this function, the showReceipt() function takes three parameters: the userID of the logged-in user, an
array of cartItems containing the items and their corresponding quantities in the user's cart, and the 
payment amount. The function first checks if the user is logged in, and then calculates the subtotal, tax, 
and total of the purchased items. The function logs the subtotal, tax, and total in the receipt. If the
payment is enough to cover the total, the function calculates the change and logs it in the receipt. If the 
payment is not enough to cover the total, the function logs a message indicating that the payment is 
insufficient. If the user is not logged in, the function logs a message asking the user to log in to show 
the receipt.



*/


  //Log in User

    loginUser("aziviva", "aziacosta143");

console.log("--------------------------------------")

  // Add to Cart
  addToCart(0); 
  addToCart(1); 
  addToCart(2); 
    
  console.log("--------------------------------------")
  // Confirm Order
    confirmOrder(userID, cartItems); // Confirm order for the cart items

    console.log("--------------------------------------")
  // Deduct Stocks
    deductStocks(userID, cartItems); // Deduct stocks for the purchased items
    console.log("--------------------------------------")

  // Show Receipt
    showReceipt(userID, cartItems, 2000); // Show receipt with payment of P1200
  

  