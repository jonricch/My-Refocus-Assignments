let customer = {
    customer_name: "Johnny Manggo",
    points: 12300,
    cart: [
        {
            item:"Shampoo",
            quantity: 2,
            price_$: 3
        },
        {
            item:"Soap",
            quantity: 2,
            price_$: 2
        },
        {
            item: "Tootpaste",
            quantity: 1,
            price_$: 3
        }
        
    ]

    
}

console.log(`Hi,${customer.customer_name}! We are happy to see you today.
Your cuurent points are: ${customer.points}`)

var total_bill = 0


console.log("Purchase Items:")
for( i = 0 ; i < customer.cart.length; i++){
    customer.points += customer.cart[i].quantity;
    total_bill += customer.cart[i].quantity * customer.cart[i].price_$;
    console.log(customer.cart[i].quantity + " x " + customer.cart[i].item + "---- $" + customer.cart[i].quantity * customer.cart[i].price_$ +".00");
  
} 

console.log("Total bill: $" + total_bill + ".00")
console.log("New Current Points : " + customer.points )



    










