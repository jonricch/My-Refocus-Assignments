const flowers = ["rose", "star gazer", "tulips", "sun flower"];

for (let i = 0; i < flowers.length; i++) {
  console.log(flowers[i].length);
}

/*
here are a couple of issues with the code:

1. The flowers array has only one element, which is a string containing all the flowers separated by commas. 
Instead, we should have an array with individual strings for each flower.
2. The loop is going one index past the last index of the flowers array because of the <= operator. Instead,
we should use the < operator.
3. The code is always printing the length of the first element in the flowers array 
(i.e., flowers[0].length), rather than the length of the current element. Instead, 
we should use the i variable to access the current element of the array.
  
 */